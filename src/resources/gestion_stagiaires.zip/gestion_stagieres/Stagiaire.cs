﻿namespace gestion_stagieres
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    public class Stagiaire
    {
        //initialisation des variables associer avec programme
        private int numero;
        private string nom;
        private string prenom;
        private DateTime dateDeNaissance;
        private int age;
        private string sexe;
        private Programme programme;

        //initialisation des proprietes associer aux variables avec programme
        public int Numero { get { return numero; } }
        public string Nom { get { return nom; } }
        public string Prenom { get { return prenom; } }
        public DateTime DateDeNaissance { get { return dateDeNaissance; } }
        public int Age { get { return age; } }
        public string Sexe { get { return sexe; } }
        public Programme Programme { get { return programme; } }

        //Constructeur
        public Stagiaire(int numero, string nom, string prenom, DateTime date, string sexe, Programme programme)
        {
            this.numero = numero;
            this.nom = nom;
            this.prenom = prenom;
            this.dateDeNaissance = date;
            this.sexe = sexe;
            this.programme = programme;

            //utiliser la date de naissance pour obtenir l'age
            DateTime today = DateTime.Now;
            this.age = (today.Subtract(date).Days)/365;

        }
    }
}
