﻿namespace gestion_stagieres
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.Data.SqlClient;


    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // creation des listes stagieres et programmes
        List<Stagiaire> stagiaires = new List<Stagiaire>();
        List<Programme> programmes = new List<Programme>();

        public MainWindow()
        {
            //Chargement des composants
            InitializeComponent();
        }

        private void btnEffacer_Click(object sender, RoutedEventArgs e)
        {
            // remet les champs des textbox vide quand on clique sur le button effacer
            clearProgrammeTab();
        }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //verifie si le champ du textbox numero est vide
                if (String.IsNullOrEmpty(txtboxNumero.Text) || int.Parse(txtboxNumero.Text) <= 0)
                {
                    MessageBox.Show("Entrer une valeur numerique entiere superieur a 0 pour le numero");
                }
                //verifie si le champ du textbox numero est vide
                else if (String.IsNullOrEmpty(txtboxNom.Text))
                {
                    MessageBox.Show("Entrer le nom du programme");
                }
                //verifie si le champ du textbox numero est vide
                else if (String.IsNullOrEmpty(txtboxDuree.Text) || int.Parse(txtboxDuree.Text) <= 0)
                {
                    MessageBox.Show("Entrer une valeur numerique entiere superieur a 0 pour la duree");
                }
                else
                {
                    // declaration de variable ppour verifier si le nouveaux programme est unque en terme de nom et de numero
                    bool unique = true;
                    foreach (Programme programme in programmes)
                    {
                        // si le numero entrer est deja dans la liste un message s'affiche
                        if (programme.Numero == int.Parse(txtboxNumero.Text))
                        {
                            MessageBox.Show("Ce numero de programme existe deja");
                            unique = false;
                        }
                        // si le nom entrer est deja dans la liste un message s'affiche
                        else if (programme.Nom == txtboxNom.Text)
                        {
                            MessageBox.Show("Ce nom de programme existe deja");
                            unique = false;
                        }
                    }

                    // si la valeur de la variable unique est true, ajouter le programme
                    if (unique)
                    {
                        Programme p = new Programme(int.Parse(txtboxNumero.Text), txtboxNom.Text, int.Parse(txtboxDuree.Text));
                        programmes.Add(p);
                        MessageBox.Show("Programme ajouté!");

                        // vide les champs apres la confirmation pour faciliter la prochaine entree de donnees
                        clearProgrammeTab();
                    }


                }

                // efface le contenu du DataGrid
                tblProgramme.Items.Clear();

                // affiche tout les stagiaires dans le DataGrid tblConsulter dont leur numero de programme est egal a nP
                foreach (Programme p in programmes)
                {
                    //if (p.Programme.Numero == nP)
                    tblProgramme.Items.Add(p);
                }
            }
            // Message d'erreur en cas d'exception
            catch
            {
                MessageBox.Show("Erreur dans vos entrées! Vérifier et réessayer.");
            }


            
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            //declaration des variables pour verifier si numero ou nom existe dans la liste programmes
            bool nomExist = false;
            bool numExist = false;

            // pour chaque programme dans la liste programmes, fait ceci
            foreach (Programme programme in programmes)
            {
                // si le nom entrer dans le textbox est egal a un nom dans la liste programmes, change la valeur de nomExist a true 
                if (txtboxNom.Text == programme.Nom)
                    nomExist = true;
                // si le numero entrer dans le textbox est egal a un numero dans la liste programmes, change la valeur de numExist a true
                if (int.Parse(txtboxNumero.Text) == programme.Numero)
                    numExist = true;

                // si les valeurs de nomExist ou numExist sont egal a true, enlever ce programme
                if (nomExist || numExist)
                {
                    programmes.Remove(programme);
                    MessageBox.Show("Programme supprimé");
                    clearProgrammeTab();
                    break;

                }

            }

            // si les valeurs de nomExist ou numExist sont egal a false, ce message s'affiche
            if (nomExist == false && numExist == false)
                MessageBox.Show("Programme inexistant! Vérifier le nom ou le numéro du programme");



        }

        private void btnEffacerStag_Click(object sender, RoutedEventArgs e)
        {
            // remet les champs des textbox vide quand on clique sur le button effacer
            clearStagiaireTab();
        }

        private void btnAjouterStag_Click(object sender, RoutedEventArgs e)
        {
            // verifie si un des radio buttons est cocher et assigne un nom à la variable sexe dépendamment du button cocher
            string sexe = "";
            if ((bool)rbA.IsChecked)
                sexe = "Autre";
            else if ((bool)rbM.IsChecked)
                sexe = "Masculin";
            else if ((bool)rbF.IsChecked)
                sexe = "Feminin";

            try
            {
                //verifie si le champ du textbox est vide
                if (String.IsNullOrEmpty(txtboxNumeroStag.Text) || int.Parse(txtboxNumeroStag.Text) <= 0)
                {
                    MessageBox.Show("Entrer une valeur numerique entiere superieur a 0 pour le numero");
                }
                //verifie si le champ du textbox est vide
                else if (String.IsNullOrEmpty(txtboxNomStag.Text))
                {
                    MessageBox.Show("Entrer le nom du stagiere");
                }
                //verifie si le champ du textbox est vide
                else if (String.IsNullOrEmpty(txtboxPrenomStag.Text))
                {
                    MessageBox.Show("Entrer le prenom du stagiere");
                }
                //verifie si le champ du textbox est vide
                else if (String.IsNullOrEmpty(txtboxDate.Text))
                {
                    MessageBox.Show("Selectionner la date de naissance du stagiere");
                }
                //verifie si le champ du textbox est vide
                else if (String.IsNullOrEmpty(sexe))
                {
                    MessageBox.Show("Selectionner le sexe du stagiere");
                }
                //verifie si un programme est selectionne dans le comboBox
                else if (cmbProgramme.SelectedItem == null)
                {
                    MessageBox.Show("Selectionner un programme!");
                }
                else
                {
                    // assigne le nom du programme selectionner a partir du comboBox
                    string nomProgrammeSelectione = cmbProgramme.SelectedItem.ToString();

                    // pour chaque programme dans la liste programmes, fait ceci
                    foreach (Programme p in programmes)
                    {
                        //verifie si le nom du programme p est egal au nom  du programme selectione
                        if (p.Nom == nomProgrammeSelectione)
                        {
                            //ajoute un nouveau stagiaire
                            Stagiaire s = new Stagiaire(int.Parse(txtboxNumeroStag.Text), txtboxNomStag.Text, txtboxPrenomStag.Text, (DateTime)txtboxDate.SelectedDate, sexe, p);
                            stagiaires.Add(s);
                            MessageBox.Show("Stagiaire Ajouté");

                            //vider les champs pour la prochaine entree de donnees
                            clearStagiaireTab();
                            break;
                        }
                    }
                }

                // efface le contenu du DataGrid
                tblStagiaire.Items.Clear();

                // affiche tout les stagiaires dans le DataGrid tblConsulter dont leur numero de programme est egal a nP
                foreach (Stagiaire s in stagiaires)
                {
                    //if (p.Programme.Numero == nP)
                    tblStagiaire.Items.Add(s);
                }
            }
            //Message en cas d'exception
            catch
            {
                MessageBox.Show("Erreur dans vos entrées! Vérifier et réessayer.");
            }
            
        }

        private void btnSupprimerStag_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // variable boolean mis a false qui va verifier si le stagiaire existe deja
                bool exist = false;

                // pour chaque stagiaire dans stagieres, execute ce code
                foreach (Stagiaire s in stagiaires)
                {
                    // verifie si le stagiaire existe et si oui Le supprime
                    if (s.Numero == int.Parse(txtboxNumeroStag.Text))
                    {
                        stagiaires.Remove(s);
                        exist = true;
                        MessageBox.Show("Stagiaire supprimé");
                        
                        //vider les champs pour la prochaine entree de donnees
                        clearStagiaireTab();
                        break;
                    }
                }

                //si le stagiaire n'existe pas, recevez ce message
                if (exist == false)
                    MessageBox.Show("Stagiaire Introuvable, Verifier le numero du stagiaire");
            }

            //Message en cas d'exception
            catch
            {
                MessageBox.Show("Veuillez entrer une valeur numerique seulement");
            }
        }

        private void cmbProgramme_Loaded(object sender, RoutedEventArgs e)
        {
            // efface le contenu dans le combo box
            cmbProgramme.Items.Clear();

            //charger le comboBox avec le nom de chaque programme
            foreach (Programme p in programmes)
                cmbProgramme.Items.Add(p.Nom);

        }

        private void cmbNumProgramme_Loaded(object sender, RoutedEventArgs e)
        {
            // efface le contenu dans le combo box
            cmbNumProgramme.Items.Clear();

            //charger le comboBox avec le numero de chaque programme
            foreach (Programme p in programmes)
                cmbNumProgramme.Items.Add(p.Numero);
        }

        private void btnRecherche_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //recupere le numero du programme selectionner dansc le ComboBox
                int nP = int.Parse(cmbNumProgramme.SelectedItem.ToString());

                // efface le contenu du DataGrid
                tblConsulter.Items.Clear();

                // affiche tout les stagiaires dans le DataGrid tblConsulter dont leur numero de programme est egal a nP
                foreach (Stagiaire s in stagiaires)
                    if (s.Programme.Numero == nP)
                        tblConsulter.Items.Add(s);
            }

            //Message en cas d'exception
            catch
            {
                MessageBox.Show("Sélectionner un numero de programme et réessayer!");
            }
        }

        // fonction pour vider les champs de l'onglet Programme
        public void clearProgrammeTab()
        {
            txtboxNumero.Text = "";
            txtboxNom.Text = "";
            txtboxDuree.Text = "";
        }

        // fonction pour vider les champs de l'onglet Stagiaire
        public void clearStagiaireTab()
        {
            txtboxNumeroStag.Text = "";
            txtboxNomStag.Text = "";
            txtboxPrenomStag.Text = "";
            txtboxDate.Text = "";
            rbA.IsChecked = false;
            rbM.IsChecked = false;
            rbF.IsChecked = false;
            cmbProgramme.SelectedItem = null;
        }


    }
}