﻿namespace gestion_stagieres
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// word.
    /// </summary>
    public class Programme
    {
        //initialisation des variables associer avec programme
        private int numero;
        private string nom;
        private int duree;

        //initialisation des proprietes associer aux variables avec programme
        public int Numero { get { return this.numero; } }
        public string Nom { get { return this.nom; } }
        public int Duree { get { return this.duree; } }
            
        //Constructeur
        public Programme(int numero, string nom, int duree)
        {
            this.numero = numero;
            this.nom = nom;
            this.duree = duree;

        }

        

        
    }
}
