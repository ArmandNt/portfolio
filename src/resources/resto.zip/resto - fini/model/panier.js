import connectionPromise from "../connection.js";

export const getPanier = async () => {
    let connection = await connectionPromise;
    let result = connection.query(
        `select panier.id_utilisateur, produit.id_produit, produit.nom, produit.prix, produit.chemin_image, panier.quantite
        from produit, panier
        where produit.id_produit=panier.id_produit`
    );
    return result;

}

export const removeElementOrAllPanier = async (product_id,user_id) => {
    
    if(product_id==0){
        let connection = await connectionPromise;
        await connection.query(
        `DELETE FROM panier WHERE id_produit >0 AND id_utilisateur = `+ user_id +``
        );
    }
    else{
        let connection = await connectionPromise;
        await connection.query(
        `DELETE FROM panier WHERE id_produit = ` + product_id + ` AND id_utilisateur = `+ user_id +``
        );

    }
    
    

}


export const updatePanier = async(
    user_id,
    product_id,
    quantite)=>{
        let connection = await connectionPromise;
        let result = await connection.query(
            `UPDATE panier SET quantite = ` + quantite + ` WHERE id_utilisateur = ` + user_id + ` AND id_produit = ` + product_id + ``
        );

    }