import { response } from "express";
import connectionPromise from "../connection.js";
import { getPanier } from "./panier.js";

export const AjouterCommande = async (user_id) => {
    let connection = await connectionPromise;
    var date = new Date();
    date.setHours(date.getHours()-5);
    let today = date.toISOString().slice(0, 19).replace('T',' ');
    let result = await connection.query(
        `INSERT INTO commande(id_utilisateur, id_etat_commande, datetime)
        VALUES(`+ user_id +`,1,'`+ today +`')`
    );

    let panier = await getPanier();
    
    for(let elPanier of panier){
        await connection.query(`Insert into commande_produit(id_commande,id_produit,quantite)
        Values(`+result.insertId+`,`+ elPanier.id_produit+`, `+ elPanier.quantite +`)`);
    }
    

}

export const getCommandes = async () => {
    let connection = await connectionPromise;
    let result = await connection.query(
        `SELECT * FROM commande`
    );
    return result;
}

export const updateCommande = async (
    data,
    ) => {
        const {idEtatCommande, 
            id_commande
        } = data;
    let connection = await connectionPromise;
    let result = await connection.query(
        `UPDATE commande SET id_etat_commande = ${idEtatCommande} WHERE id_commande = ${id_commande}`
    );
}