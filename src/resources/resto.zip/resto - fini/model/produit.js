import connectionPromise from "../connection.js"; 

//function pour montrer tout les produits
export const getProduits = async () => {
    let connection = await connectionPromise;
    let result = await connection.query(
        `SELECT * FROM produit`
    );
    
    return result;
}

export const addProduit = async(
    user_id,
    product_id,
    quantite
    ) =>{
            let exist=false;
            let connection = await connectionPromise;
            let result = await connection.query(
            `Select * from panier`);
            result.forEach(element => {
                
                if (element.id_produit==product_id){
                    return exist=true;
                }
            });

            

            if(exist==true){
                await connection.query(`UPDATE panier SET quantite = `+quantite+` WHERE id_utilisateur = `+user_id+` 
                AND id_produit = `+product_id+``)
            } else{
                await connection.query(`Insert panier (id_utilisateur,id_produit,quantite)
                values(`+ user_id +`,`+ product_id +`,`+quantite+`)`)
            }


       
}