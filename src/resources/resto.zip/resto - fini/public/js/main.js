let btns = document.querySelectorAll('.btn');
let qtys = document.querySelectorAll('.qty');
const selects = document.querySelectorAll('.etat-commande');

const ajoutAuPanier = (event) => {
    let pID = event.target.parentNode.dataset.id;
    let qty = parseInt(event.target.previousElementSibling.value);
    if (qty > 0 && qty <= 10) {
        let data = {
            user_id: 1,
            product_id: pID,
            quantite: parseInt(qty)
        };

        fetch('/', {
            method: 'post',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(data)
        });
    }
}

for (let btn of btns) {
    btn.addEventListener('click', ajoutAuPanier);
}

// pour le changer l'état de chaque dropdownlist dans la liste des commamndes dans le bd
selects.forEach(item => {
    item.addEventListener('change', async (e) => {
        const { value, id } = e.target;
        if (value) {
            try {
                let res = await fetch('/etat-commande', {
                    method: 'post',
                    headers: { 'Content-type': 'application/json' },
                    body: JSON.stringify({ idEtatCommande: value, id_commande: id })
                });
                res = await res.json();
            } catch (err) {
    
            }
        }
    })
});