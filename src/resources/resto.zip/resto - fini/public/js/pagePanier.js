let dltAll = document.getElementById("dltAll");
let qtys = document.querySelectorAll('.qtyp');
let btnsDlt = document.querySelectorAll('.dlt');
let confCom = document.getElementById("confCom");

let total = document.getElementById("total");
var prixTotal = 0;
var prix = [];
var qtyp =[];
qtys.forEach(element => {
    prix.push(element.parentNode.dataset.prix);
    qtyp.push(element.parentNode.dataset.quantite)
});

for(let i = 0; i < prix.length; i++) {
    prixTotal += prix[i] * qtyp[i];
}

total.innerText+= " " + prixTotal.toFixed(2)+ " $";

confCom.addEventListener("click",(event)=>{
    let data ={
        user_id:1
    }

    fetch('/panier-confirmer-commande',{
        method: 'post',
        headers: { 'Content-type' : 'application/json'},
        body: JSON.stringify(data)
    });
})

dltAll.addEventListener("click", (event)=>{
    let data={
        product_id:0,
        user_id:1
    }

    fetch('/panier-delete',{
        method: 'post',
        headers: { 'Content-type' : 'application/json'},
        body: JSON.stringify(data)
    });

    location.reload();
})

const deleteElement = (event) => {
    let pID= event.target.parentNode.dataset.id;
    
    let data={
        product_id:pID,
        user_id:1
    }
    fetch('/panier-delete',{
        method: 'post',
        headers: { 'Content-type' : 'application/json'},
        body: JSON.stringify(data)
    });
    location.reload();
   
}

const updateElPanier = (event) => {
    let pQty= event.target.value;
    let pID= event.target.parentNode.dataset.id;
    if(pQty>0 && pQty<=10){
        let data ={
            user_id:1,
            product_id:pID,
            quantite: parseInt(pQty)
        }

        fetch('/panier',{
            method: 'post',
            headers: { 'Content-type' : 'application/json'},
            body: JSON.stringify(data)
        });

        location.reload();

        
    }
}

for (let btn of btnsDlt){
    btn.addEventListener('click',deleteElement);  
}

for (let qty of qtys){
    qty.addEventListener('blur',updateElPanier)
}