let btnss = document.querySelectorAll('.btn');
let qtyss = document.querySelectorAll('.qtyp');

const validateQty =(event)=>{
    let qty= event.target.previousElementSibling;
    let erreurQty = event.target.nextElementSibling;
    if(qty.validity.valid){
        erreurQty.innerText='';
        erreurQty.classList.remove('on');
    }
    else{
        erreurQty.classList.add('on');
        if( parseInt(qty.value)<0){
            erreurQty.innerText='Veuillez entrer une valeur entre 1 et 10';
            
        }
        else if(parseInt(qty.value)>10){
            erreurQty.innerText='Maximun 10 unités par article';
            
        }
        
    }

}
const validateQtyPanier =(event)=>{
    let qty= event.target;
    let erreurQty = event.target.nextElementSibling.nextElementSibling;
    
    if(qty.validity.valid){
        erreurQty.innerText='';
        erreurQty.classList.remove('on');
    }
    else{
        erreurQty.classList.add('on');
        if( parseInt(qty.value)<0){
            erreurQty.innerText='Veuillez entrer une valeur entre 1 et 10';
            
        }
        else if(parseInt(qty.value)>10){
            erreurQty.innerText='Maximun 10 unités par article';
            
        }
        
    }

}

for (let btn of btnss){
        btn.addEventListener('click', validateQty);
}

for (let qty of qtyss){
        qty.addEventListener('blur', validateQtyPanier);
}