import connectionPromise from "./connection.js";

let connection = await connectionPromise;

export const validateProductId = async (product_id)=>{
    
    let result1 = await connection.query(`SELECT * FROM produit WHERE id_produit = ( SELECT MAX( id_produit ) FROM produit )`);

    
    return !!product_id &&
        typeof product_id === 'number' &&
        product_id <= result1[0].id_produit &&
        product_id > 0;
    
}

export const  validateUserId = async (user_id)=>{
    let result1 = await connection.query(`SELECT * FROM utilisateur WHERE id_utilisateur =`+ user_id +``);
    
    return !!user_id &&
        typeof user_id==='number' &&
        user_id==result1[0].id_utilisateur;


}

export const validateQuantite =(quantite)=>{
    return !!quantite &&
        typeof quantite==='number'&&
        quantite>0 &&
        quantite <= 10;
}