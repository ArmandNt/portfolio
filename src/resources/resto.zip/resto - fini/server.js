// Aller chercher les configurations de l'application
import 'dotenv/config';

// Importer les fichiers et librairies
import express, { json, request, response, urlencoded } from 'express';
import expressHandlebars from 'express-handlebars';
import helmet from 'helmet';
import compression from 'compression';
import cors from 'cors';
import cspOption from './csp-options.js';
import connection from './connection.js';
import { getProduits,addProduit } from './model/produit.js';
import { getPanier, removeElementOrAllPanier, updatePanier } from './model/panier.js';
import { getCommandes, AjouterCommande, updateCommande } from './model/commandes.js';
import { validateProductId,validateQuantite,validateUserId } from './validationServer.js';

// Création du serveur
const app = express();
app.engine('handlebars', expressHandlebars());
app.set('view engine', 'handlebars');

// Ajout de middlewares
app.use(helmet(cspOption));
app.use(compression());
app.use(cors());
app.use(json());
app.use(urlencoded({ extended: false }));
app.use(express.static('public'));

// Ajouter les routes ici ...
app
    .get('/', async (request, response) => {
    response.render('menu',{
        titre:'Menu',
        produits: await getProduits()

    });
    })


    

    .post('/', async (request,response) => {
        if(validateUserId(request.body.user_id)&&
           validateProductId(request.body.product_id) &&
           validateQuantite(request.body.quantite)){
            await addProduit(
            request.body.user_id,
            request.body.product_id,
            request.body.quantite);
        }
        

        response.sendStatus(201);

    })

    .get('/panier', async (request, response) => {
        response.render('panier',{
            titre: 'Panier',
            elemPanier: await getPanier()
        });
    })

    .post('/panier', async (request,response)=>{
        if(validateUserId(request.body.user_id)&&
           validateProductId(request.body.product_id) &&
           validateQuantite(request.body.quantite)){
                await updatePanier(
                request.body.user_id,
                request.body.product_id,
                request.body.quantite);
           }
        
    })

    .post('/panier-delete', async (request,response)=>{
        if(validateUserId(request.body.user_id)&&
           validateProductId(request.body.product_id)){
                await removeElementOrAllPanier(
                request.body.product_id,
                request.body.user_id);
           }
        
    })

    .post('/panier-confirmer-commande', async (request,response)=>{
        if(validateUserId(request.body.user_id)){
            await AjouterCommande(request.body.user_id);
        }
    })

    .get ('/commandes', async (request,response) => {
        response.render('commandes',{
            titre: 'Liste des commandes',
            commandes: await getCommandes()
        });
    })

    .post('/etat-commande', async (request,response) => {
        await updateCommande(
            request.body
            );
    });

    app.get('/login', async (request, response) => {
        response.render('login',{
            titre: 'Log In',
            // login: await getProduits()
        });
    });

    app.get('/creerCompte', async (request, response) => {
        response.render('creerCompte',{
            titre: 'Créer un Compte',
            // login: await getProduits()
        });
    });

// Renvoyer une erreur 404 pour les routes non définies
app.use(function (request, response) {
    // Renvoyer simplement une chaîne de caractère indiquant que la page n'existe pas
    response.status(404).send(request.originalUrl + ' not found.');
});

// Démarrage du serveur
app.listen(process.env.PORT);
console.info(`Serveurs démarré:`);
console.info(`http://localhost:${ process.env.PORT }`);

